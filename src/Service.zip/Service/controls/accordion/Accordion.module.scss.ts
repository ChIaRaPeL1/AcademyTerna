/* tslint:disable */
require("./Accordion.module.css");
const styles = {
  accordion: 'accordion_f9202eea',
  drawer: 'drawer_f9202eea',
  accordionChevron: 'accordionChevron_f9202eea'
};

export default styles;
/* tslint:enable */