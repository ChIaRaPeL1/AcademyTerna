/* tslint:disable */
require("./NewsSecondLivel.module.css");
const styles = {
  newsSecondLivel: 'newsSecondLivel_bfc790d1',
  container: 'container_bfc790d1',
  row: 'row_bfc790d1',
  column: 'column_bfc790d1',
  'ms-Grid': 'ms-Grid_bfc790d1',
  title: 'title_bfc790d1',
  subTitle: 'subTitle_bfc790d1',
  description: 'description_bfc790d1',
  detail: 'detail_bfc790d1',
  newsItem: 'newsItem_bfc790d1',
  link: 'link_bfc790d1',
  linkButtonMobile: 'linkButtonMobile_bfc790d1',
  buttonMobile: 'buttonMobile_bfc790d1',
  button: 'button_bfc790d1',
  label: 'label_bfc790d1',
  buttonRowMobile: 'buttonRowMobile_bfc790d1',
  pnpImageCarousel: 'pnpImageCarousel_bfc790d1',
  carouselCustomSize: 'carouselCustomSize_bfc790d1',
  imgCarouselHome: 'imgCarouselHome_bfc790d1',
  imgCarouselHomeNoTitle: 'imgCarouselHomeNoTitle_bfc790d1',
  newsContainer: 'newsContainer_bfc790d1'
};

export default styles;
/* tslint:enable */