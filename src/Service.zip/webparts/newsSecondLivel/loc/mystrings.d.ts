declare interface INewsSecondLivelWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NewsSecondLivelWebPartStrings' {
  const strings: INewsSecondLivelWebPartStrings;
  export = strings;
}
