/* tslint:disable */
require("./Footer.module.css");
const styles = {
  ternaFooter: 'ternaFooter_1fade851',
  container: 'container_1fade851',
  row: 'row_1fade851',
  column: 'column_1fade851',
  'ms-Grid': 'ms-Grid_1fade851',
  title: 'title_1fade851',
  subTitle: 'subTitle_1fade851',
  description: 'description_1fade851',
  button: 'button_1fade851',
  label: 'label_1fade851',
  'img-terna': 'img-terna_1fade851',
  'img-mail': 'img-mail_1fade851',
  'action-social': 'action-social_1fade851',
  facebook: 'facebook_1fade851',
  youtube: 'youtube_1fade851',
  twitter: 'twitter_1fade851',
  dFlex: 'dFlex_1fade851',
  'wrapper-social': 'wrapper-social_1fade851',
  'wrapper-info-terna': 'wrapper-info-terna_1fade851',
  'row-footer': 'row-footer_1fade851',
  'wrapper-mail': 'wrapper-mail_1fade851',
  'label-mail': 'label-mail_1fade851',
  'ms-SPLegacyFabricBlock': 'ms-SPLegacyFabricBlock_1fade851',
  centerFooter: 'centerFooter_1fade851',
  logoFooter: 'logoFooter_1fade851',
  customTernaFooter: 'customTernaFooter_1fade851',
  centerFooterMail: 'centerFooterMail_1fade851',
  logoFooterDesktop: 'logoFooterDesktop_1fade851',
  socialIconCustom: 'socialIconCustom_1fade851'
};

export default styles;
/* tslint:enable */