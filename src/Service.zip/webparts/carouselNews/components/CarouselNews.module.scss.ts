/* tslint:disable */
require("./CarouselNews.module.css");
const styles = {
  carouselNews: 'carouselNews_8af04a56',
  container: 'container_8af04a56',
  row: 'row_8af04a56',
  column: 'column_8af04a56',
  'ms-Grid': 'ms-Grid_8af04a56',
  title: 'title_8af04a56',
  subTitle: 'subTitle_8af04a56',
  description: 'description_8af04a56',
  button: 'button_8af04a56',
  label: 'label_8af04a56',
  containerCarousel: 'containerCarousel_8af04a56',
  pnpImageCarousel: 'pnpImageCarousel_8af04a56',
  carouselCustomSize: 'carouselCustomSize_8af04a56',
  imgCarouselHome: 'imgCarouselHome_8af04a56',
  imgCarouselHomeNoTitle: 'imgCarouselHomeNoTitle_8af04a56',
  carouselContent: 'carouselContent_8af04a56',
  hideArrows: 'hideArrows_8af04a56',
  wrapperTitle: 'wrapperTitle_8af04a56',
  fontBold: 'fontBold_8af04a56'
};

export default styles;
/* tslint:enable */