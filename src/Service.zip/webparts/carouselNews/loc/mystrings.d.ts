declare interface ICarouselNewsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CarouselNewsWebPartStrings' {
  const strings: ICarouselNewsWebPartStrings;
  export = strings;
}
