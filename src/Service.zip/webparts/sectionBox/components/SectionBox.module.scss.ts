/* tslint:disable */
require("./SectionBox.module.css");
const styles = {
  sectionBox: 'sectionBox_1420ae50',
  container: 'container_1420ae50',
  row: 'row_1420ae50',
  column: 'column_1420ae50',
  'ms-Grid': 'ms-Grid_1420ae50',
  columnDirigenti: 'columnDirigenti_1420ae50',
  columnDipendenti: 'columnDipendenti_1420ae50',
  Faculty: 'Faculty_1420ae50',
  Rituals: 'Rituals_1420ae50',
  title: 'title_1420ae50',
  description: 'description_1420ae50',
  button: 'button_1420ae50',
  label: 'label_1420ae50',
  labelFaculty: 'labelFaculty_1420ae50',
  spec: 'spec_1420ae50',
  labelspec: 'labelspec_1420ae50',
  imageIcon: 'imageIcon_1420ae50'
};

export default styles;
/* tslint:enable */