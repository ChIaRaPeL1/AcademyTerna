declare interface ISectionBoxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SectionBoxWebPartStrings' {
  const strings: ISectionBoxWebPartStrings;
  export = strings;
}
