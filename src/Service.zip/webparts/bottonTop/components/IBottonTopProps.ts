import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IBottonTopProps {
  description: string;
  context: WebPartContext;
}
