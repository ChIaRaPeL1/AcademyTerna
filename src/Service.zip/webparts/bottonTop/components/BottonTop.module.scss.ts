/* tslint:disable */
require("./BottonTop.module.css");
const styles = {
  bottonTop: 'bottonTop_3a0b6c8c',
  container: 'container_3a0b6c8c',
  row: 'row_3a0b6c8c',
  column: 'column_3a0b6c8c',
  'ms-Grid': 'ms-Grid_3a0b6c8c',
  title: 'title_3a0b6c8c',
  subTitle: 'subTitle_3a0b6c8c',
  description: 'description_3a0b6c8c',
  button: 'button_3a0b6c8c',
  label: 'label_3a0b6c8c',
  goToTop: 'goToTop_3a0b6c8c'
};

export default styles;
/* tslint:enable */