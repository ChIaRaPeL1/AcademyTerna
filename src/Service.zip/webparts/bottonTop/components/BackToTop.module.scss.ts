/* tslint:disable */
require("./BackToTop.module.css");
const styles = {
  backToTop: 'backToTop_bc54c7b5',
  iconButton: 'iconButton_bc54c7b5',
  icon: 'icon_bc54c7b5'
};

export default styles;
/* tslint:enable */