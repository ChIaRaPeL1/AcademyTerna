declare interface IBottonTopWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BottonTopWebPartStrings' {
  const strings: IBottonTopWebPartStrings;
  export = strings;
}
