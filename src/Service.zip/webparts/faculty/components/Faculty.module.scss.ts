/* tslint:disable */
require("./Faculty.module.css");
const styles = {
  faculty: 'faculty_acd3f920',
  container: 'container_acd3f920',
  description: 'description_acd3f920',
  button: 'button_acd3f920',
  label: 'label_acd3f920',
  filterContainer: 'filterContainer_acd3f920',
  containerDropdownPerson: 'containerDropdownPerson_acd3f920',
  containerDropdownRole: 'containerDropdownRole_acd3f920',
  containerDropdownSpecialization: 'containerDropdownSpecialization_acd3f920',
  documentCardContainer: 'documentCardContainer_acd3f920',
  documentCardContent: 'documentCardContent_acd3f920',
  email: 'email_acd3f920',
  emailMobile: 'emailMobile_acd3f920',
  specialization: 'specialization_acd3f920',
  specializationText: 'specializationText_acd3f920',
  roleText: 'roleText_acd3f920',
  paginazione: 'paginazione_acd3f920'
};

export default styles;
/* tslint:enable */