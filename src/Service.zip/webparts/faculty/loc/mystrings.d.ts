declare interface IFacultyWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FacultyWebPartStrings' {
  const strings: IFacultyWebPartStrings;
  export = strings;
}
