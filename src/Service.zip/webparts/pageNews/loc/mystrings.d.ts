declare interface IPageNewsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PageNewsWebPartStrings' {
  const strings: IPageNewsWebPartStrings;
  export = strings;
}
